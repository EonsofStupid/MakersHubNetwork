import { HomeView } from "@/features/home/HomeView";

const IndexPage = () => {
  return <HomeView />;
};

export default IndexPage;